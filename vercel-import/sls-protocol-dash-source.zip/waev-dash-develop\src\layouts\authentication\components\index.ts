export * from './ForgotPassword';
export * from './Register';
export * from './RenewToken';
export * from './SignIn';
export * from './MagicLink';

export * from './Footer';
