## Multilingual Support

1. The command `npm run messages:extract` extract the messages from the source code to messages.json file.
2. The command `npm run messages:compile` compiles the messages.json file into language specific json files. These are imported in the application.
3. The command `npm run translations` runs both the extraction script and the compilation script for the messages.
