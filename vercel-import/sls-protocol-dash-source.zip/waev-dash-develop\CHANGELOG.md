# Change Log

## [0.1.0]

### Late Summer Feature Release

- Linking with Middleware v1.1
- JWT Expiration
- Removed Spraypaint
- Click to view Record
- Home Page
- Terms and Conditions
- Loaders
- Entity Auto-Select
- Conditional Favicons
- Notifications
- Invisible Button Removal
- First Name and Last Name to User Creation
- TOTP does not auto-fire when invalid
- Permissions - Toggle Elements
- Wrap Contexts with Provider Composer
- Records Updates to Middleware
- ...
- Various Bugfixes and Performance Boosts

## [0.0.0] 2022-02-14

### Original Release