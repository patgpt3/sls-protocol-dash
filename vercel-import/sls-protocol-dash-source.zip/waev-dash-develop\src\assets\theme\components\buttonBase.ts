// types
type Types = any;

const buttonBase: Types = {
  defaultProps: {
    disableRipple: false,
  },
};

export default buttonBase;
